const commando = require('discord.js-commando');
const bot = new commando.Client();

bot.registry.registerGroup('random', 'Random');
bot.registry.registerDefaults();
bot.registry.registerCommandsIn(__dirname + "/commands");

bot.login('Mzk4NTkxMzU0NTcxMTk0MzY4.DTCP4A.aN3ij2l0S6FQXrBApn__z_daO4s');